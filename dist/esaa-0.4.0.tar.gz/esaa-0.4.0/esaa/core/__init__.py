# ESAA core engine
